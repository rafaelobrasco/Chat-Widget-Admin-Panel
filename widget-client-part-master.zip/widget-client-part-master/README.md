To start using this code, first of all we have to download or clone this repo on our computer.
Then If you don't have installed Node.js on your computer use this link https://nodejs.org/en/ to download it and install it.
Open folder with code of the project with 'terminal' and run command ```npm install``` or ```npm i```.
If installion done successfuly, type command ```npm start``` and run it.
Then create user name, after that you can start typing messages to the chat.
