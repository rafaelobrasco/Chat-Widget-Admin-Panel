import React from 'react';
import User_Chat from "./user-chat/UserChat";
import './App.css';

function App() {
  return (
    <User_Chat />
  );
}

export default App;
