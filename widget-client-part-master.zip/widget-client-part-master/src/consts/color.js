const mainColor = '#29b6f6';
const textColor = "#858585";
const archiveColor = "#a2a2a2";
const white = "#fff";
const red = "#ff1744";
const black = "#3d3d3d";
const lightGray = "#f1f2f6";

export {
  mainColor,
  textColor,
  archiveColor,
  white,
  red,
  black,
  lightGray
}