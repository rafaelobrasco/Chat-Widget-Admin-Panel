export const projectID = "0e7fe485-287d-499b-849e-87921fc55f4c";
export const key =  "9e99c603-9450-4beb-8812-0826a8de2a06";
export const secret = "wsKfKLcuD3Jg070ai52DP8YPqCqCSuYfsOrfliunMoINQ4JsUfRomoUb4+BjgeJXmSJqZlU5VzfUwoHtadNnZw==";
