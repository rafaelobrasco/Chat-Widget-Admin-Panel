import Archive from '../assets/archive.svg';
import ChatLogo from '../assets/comments.svg';
import Arrow from '../assets/arrow.svg';
import SendMessage from "../assets/send_msg.svg";

export  {
  ChatLogo,
  Archive,
  Arrow,
  SendMessage,
};